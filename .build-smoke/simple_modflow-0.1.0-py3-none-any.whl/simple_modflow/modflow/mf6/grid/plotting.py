from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

import figs as f
import geopandas as gpd
import numpy as np
import plotly.graph_objects as go
import shapely as shp
from flopy.discretization.vertexgrid import VertexGrid
from flopy.plot.crosssection import PlotCrossSection

from simple_modflow.modflow.utils.datatypes.choros import Choro
from simple_modflow.modflow.utils.datatypes.readers import read_shp_gpkg

if TYPE_CHECKING:
    from simple_modflow.modflow.mf6.mfsimbase import SimulationBase
    from simple_modflow.modflow.mf6.voronoiplus import VoronoiGridPlus


def mapit(vor, crs: str = 'EPSG:2927'):
    """
    Explore the Voronoi polygons in an interactive map.
    """
    poly = vor.get_voronoi_polygons()
    return gpd.GeoDataFrame(geometry=poly, crs=crs).explore()


def build_choropleth(
    vor,
    model: SimulationBase = None,
    kstpkper: tuple = None,
    per: int = None,
    layer: int = 0,
    type: str = 'hds',
    custom_hover: dict = None,
    custom_zs: list = None,
    zmin: float | int = None,
    zmax: float | int = None,
    zoom: int = 13,
    show_layer_elevs: bool = False,
    show_mounding: bool = False,
    hover_heads: bool = True,
    hover_ks: bool = False,
    locs: Path = None,
):
    """
    Create a Choro wrapper for Voronoi plotting.
    """
    return Choro(
        vor=vor,
        model=model,
        kstpkper=kstpkper,
        per=per,
        layer=layer,
        type=type,
        custom_hover=custom_hover,
        custom_zs=custom_zs,
        zmin=zmin,
        zmax=zmax,
        zoom=zoom,
        show_layer_elevs=show_layer_elevs,
        show_mounding=show_mounding,
        hover_heads=hover_heads,
        hover_ks=hover_ks,
        locs=locs,
    )


def get_dash_selector(vor):
    return build_choropleth(vor).dash_selector()


def show(vor):
    return build_choropleth(vor).plot()


def map_nodes(vor) -> go.Figure:
    latlonselect = vor.gdf_vorPolys.to_crs('EPSG:4326')
    latlonselect['cellidx'] = latlonselect.index.astype(str)
    geojsonselect = json.loads(latlonselect['geometry'].to_json())
    centroid_grid = vor.grid_centroid
    fig_sel = go.Figure(go.Choroplethmap(
        geojson=geojsonselect,
        locations=latlonselect['cellidx'].to_list(),
        featureidkey='id',
        z=latlonselect['cellidx'].to_list(),
        colorscale='earth'
    ))

    fig_sel.update_layout(
        margin={"r": 0, "t": 20, "l": 0, "b": 0},
        map_style="carto-positron",
        map_zoom=15,
        map_center={"lat": centroid_grid.y, "lon": centroid_grid.x},
    )

    return fig_sel


def show_selected_cells(vor, cell_list: list = None, **kwargs):
    """
    Show selected cells on the Voronoi choropleth.
    """
    choro = build_choropleth(vor, **kwargs).choropleth
    choro.data[0].selectedpoints = tuple(cell_list)
    return go.Figure(choro).show(renderer='browser')


def show_overlapping_geometry(vor, shp_gpkg):
    """
    Show cells overlapping the provided geometry.
    """
    cells = vor.get_vor_cells_as_series(shp_gpkg).to_list()
    return show_selected_cells(vor, cells)


def plot3d(vor, z=None) -> go.Figure:
    if hasattr(vor, 'x_vor_regions') and hasattr(vor, 'y_vor_regions'):
        x_lines = vor.x_vor_regions
        y_lines = vor.y_vor_regions
    else:
        x_lines = []
        y_lines = []
        for xs, ys in zip(vor.x_coords_by_node, vor.y_coords_by_node):
            x_lines.extend(list(xs) + [None])
            y_lines.extend(list(ys) + [None])

    if z is None:
        z = [0 for _ in x_lines]
    fig3d = go.Figure(
        data=go.Scatter3d(
            x=x_lines,
            y=y_lines,
            z=z,
            opacity=0.5,
            mode='lines',
            line_color='black',
        ),
        layout={'height': 1000},
    )
    if all(hasattr(vor, attr) for attr in ('x_vor', 'y_vor', 'i', 'j', 'k')):
        fig3d.add_trace(
            go.Mesh3d(
                x=vor.x_vor,
                y=vor.y_vor,
                z=[0 for _ in range(len(vor.x_vor))],
                i=vor.i,
                j=vor.j,
                k=vor.k,
                colorscale='Viridis',
                intensity=vor.x_vor,
            )
        )
    else:
        cx, cy = vor.centroids
        fig3d.add_trace(
            go.Scatter3d(
                x=cx,
                y=cy,
                z=[0 for _ in cx],
                mode='markers',
                marker=dict(size=4, color='royalblue'),
                name='centroids',
            )
        )
    fig3d.update_layout(
        title='Voronoi Diagram',
        scene=dict(
            xaxis=dict(title='X'),
            yaxis=dict(title='Y'),
            zaxis=dict(title=''),
        ),
    )
    return fig3d


def plot2d(vor) -> go.Figure:
    fig2d = go.Figure(layout=vor.scatt_layout)
    for cell in range(len(vor.x_coords_by_node)):
        fig2d.add_scattergl(
            x=vor.x_coords_by_node[cell],
            y=vor.y_coords_by_node[cell],
            opacity=1,
            mode='lines',
            line_color='black',
            line_width=1,
        )

    vor.fig2d = fig2d
    return fig2d


def plottri(vor):
    """
    Plot the triangulated mesh generated by Triangle.
    """
    df_tricells = np.asarray(vor.tri.get_cell2d())
    ilist = df_tricells[:, 4].astype(int).tolist()
    jlist = df_tricells[:, 5].astype(int).tolist()
    klist = df_tricells[:, 6].astype(int).tolist()
    xtriverts = np.asarray(vor.tri.verts)[:, 0].tolist()
    ytriverts = np.asarray(vor.tri.verts)[:, 1].tolist()

    xtricells = []
    ytricells = []
    for i, j, k in zip(ilist, jlist, klist):
        xtricells.extend([xtriverts[i], xtriverts[j], xtriverts[k], None])
        ytricells.extend([ytriverts[i], ytriverts[j], ytriverts[k], None])

    trifig2d = go.Figure(
        go.Scattergl(
            x=xtricells,
            y=ytricells,
            mode='lines',
            line_color='black',
            line_width=1,
        ),
        layout=vor.scatt_layout,
    )
    return trifig2d.show(config=vor.config)


def build_grid_section(vor: VoronoiGridPlus, line: shp.LineString | Path):
    """
    Build a cross-section helper for the Voronoi grid.
    """
    return GridSection(vor=vor, line=line)


class GridSection:
    """
    Represents a section of a grid and provides tools for creating and plotting
    cross-sections.
    """

    def __init__(self, vor, line: shp.LineString | Path):
        self.vor = vor
        props = vor.get_disv_gridprops()
        self.grid = VertexGrid(
            vertices=props['vertices'],
            top=vor.gdf_topbtm[0].values,
            botm=vor.gdf_topbtm.loc[:, 1:].values.T,
            cell2d=props['cell2d'],
            lenuni='feet',
            ncpl=props['ncpl'],
            crs=vor.crs,
            nlay=vor.nlay,
        )

        if isinstance(line, Path):
            self.coords = read_shp_gpkg(line).union_all().coords
        elif isinstance(line, shp.LineString):
            self.coords = line.coords
        else:
            raise ValueError(f'line arg must be a Path or LineString, not {type(line)}')

        self.xy = np.array([xy for xy in self.coords])

    @property
    def polys(self):
        polys = PlotCrossSection(
            modelgrid=self.grid,
            line={'line': self.xy},
        ).polygons
        return polys

    @property
    def poly_coords(self):
        poly_coords = []
        for poly in self.polys.values():
            verts = poly[0].get_xy()
            poly_coords.append(verts)
        return poly_coords

    @property
    def figure(self):
        fig = f.Fig()
        for verts in self.poly_coords:
            xs, ys = verts[:, 0], verts[:, 1]
            fig.add_trace(
                go.Scatter(
                    x=xs,
                    y=ys,
                    fill='toself',
                    mode='lines',
                    line=dict(color='black'),
                    name='Polygon',
                )
            )
        return fig

    def plot(self):
        self.figure.show()
